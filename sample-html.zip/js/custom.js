$(document).ready(function(){

    $(window).on('resize',function(){
        if( $(window).width()<768  && !$('.mobile-menu').hasClass('active') ) {
            $('.d-left').css('margin-left','-150px');
            $('.mobile-menu').removeClass('active');
        }else {
            $('.d-left').css('margin-left','0');
            
        }
    })

    $('body').on('click','.mobile-menu', function(){

        if($('.d-left').offset().left < 0) {
           $('.d-left').animate({'marginLeft':0},200);
           $(this).addClass('active');
        }else {
            $('.d-left').animate({'marginLeft':-150},200);
            $(this).removeClass('active');
        }
    });



    // Opens Popup on Mock-4.html. Call this code when required 
    //$('#userDetails').modal('show');


    // Opens Popup on Mock-9A.html. Call this code when required
    $('#userDetailsList').modal('show');

    $( "#forecastdate" ).datepicker();

});




// =================== Free Chart-1 ========================== //

var ctx = document.getElementById("myChart");
ctx.height = 100;
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
            data: [12, 19, 3, 5, 2, 3, 12, 19, 3, 5, 2, 3],
            backgroundColor: 'rgba(0, 203, 202, 1)',            
            borderWidth: 0
        },
        {
            data: [20, 8, 6, 10, 12, 13, 20, 8, 6, 10, 12, 13],
            backgroundColor: 'rgba(75, 75, 75, 1)',
            borderWidth: 0
        },
        {
            data: [6, 12, 10, 14, 16, 9, 16, 12, 10, 2, 11, 7],
            backgroundColor: 'rgba(110, 240, 130, 1)',
            borderWidth: 0
        },
        {
            data: [7, 12, 9, 12, 10, 4, 2, 1, 6, 9, 16, 11],
            backgroundColor: 'rgba(250, 150, 80, 1)',
            borderWidth: 0
        }]
    },
    options: {
        legend: {
            display: false
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});

function updateChart(chart, label, data) {
    //chart.data.labels.push(label);
    // chart.data.datasets.forEach((dataset) => {
    //     dataset.data = data;
    // });
    chart.data.datasets[0].data = data;
    chart.update();
}

var data1 = [6, 12, 10, 14, 16, 9, 16, 12, 10, 2, 11, 7];
setTimeout(function(){updateChart(myChart, 'Jan', data1 );},1000);


